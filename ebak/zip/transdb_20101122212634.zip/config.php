<?php
	$b_table="trans_m_user";
	$tb[trans_m_user]=0;

	$b_baktype=0;
	$b_filesize=300;
	$b_bakline=500;
	$b_autoauf=1;
	$b_dbname="transdb";
	$b_stru=1;
	$b_strufour=0;
	$b_dbchar="utf8";
	$b_beover=0;
	$b_insertf="replace";
	$b_autofield=",,";
	$b_bakdatatype=0;
	?>