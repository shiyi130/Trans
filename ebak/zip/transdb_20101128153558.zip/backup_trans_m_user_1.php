<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `backup_trans_m_user`;");
E_C("CREATE TABLE `backup_trans_m_user` (
  `User_Id` varchar(10) NOT NULL,
  `User_Name` varchar(20) DEFAULT NULL,
  `Author_Id` varchar(2) NOT NULL,
  PRIMARY KEY (`User_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8");
E_D("insert into `backup_trans_m_user` values('sys','管理者（陳）','2');");
E_D("insert into `backup_trans_m_user` values('user','一般ユーザ（史）','3');");

@include("../../inc/footer.php");
?>