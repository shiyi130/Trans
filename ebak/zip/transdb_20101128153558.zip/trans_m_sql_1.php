<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `trans_m_sql`;");
E_C("CREATE TABLE `trans_m_sql` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `sqlname` varchar(60) NOT NULL DEFAULT '',
  `sqltext` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8");
E_D("insert into `trans_m_sql` values('2','sel_trans_m_group','select * from trans_m_group');");

@include("../../inc/footer.php");
?>