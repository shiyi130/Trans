<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `backup_trans_m_author`;");
E_C("CREATE TABLE `backup_trans_m_author` (
  `Author_Id` varchar(2) NOT NULL,
  `Author_Name` varchar(20) DEFAULT NULL,
  `Comment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Author_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8");
E_D("insert into `backup_trans_m_author` values('1','スパー管理者','管理員のアカウント管理、管理員の権限を管理する');");
E_D("insert into `backup_trans_m_author` values('2','管理者','Insert＿data,Update＿data,delete＿data');");
E_D("insert into `backup_trans_m_author` values('3','ユーザ','Read＿data');");

@include("../../inc/footer.php");
?>