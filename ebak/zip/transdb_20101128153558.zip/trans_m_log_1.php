<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `trans_m_log`;");
E_C("CREATE TABLE `trans_m_log` (
  `loginid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `logintime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `loginip` varchar(20) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `password` varchar(30) NOT NULL DEFAULT '',
  `loginauth` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`loginid`)
) ENGINE=MyISAM AUTO_INCREMENT=163 DEFAULT CHARSET=utf8");
E_D("insert into `trans_m_log` values('13','sys','2010-10-29 22:36:17','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('14','sys','2010-10-29 22:47:06','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('15','sys','2010-10-29 22:53:32','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('16','sys','2010-10-29 22:58:28','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('17','sys','2010-10-29 23:56:19','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('18','sys','2010-10-30 00:10:38','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('19','sys','2010-10-30 00:24:46','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('20','sys','2010-10-30 00:31:43','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('21','sys','2010-10-30 00:34:13','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('22','sys','2010-10-30 00:39:39','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('23','sys','2010-10-30 00:44:14','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('24','sys','2010-10-30 00:47:40','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('25','sys','2010-10-30 00:51:34','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('26','sys','2010-10-30 00:55:32','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('27','sys','2010-10-30 01:07:13','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('28','sys','2010-10-30 01:10:20','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('29','user','2010-10-30 01:17:31','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('30','sys','2010-10-30 01:19:52','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('31','sys','2010-10-30 01:20:19','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('32','sys','2010-10-30 01:24:17','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('33','sys','2010-10-30 01:24:38','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('34','sys','2010-10-30 01:24:59','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('35','sys','2010-10-30 01:29:53','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('36','sys','2010-10-30 12:01:51','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('37','sys','2010-11-09 22:52:02','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('38','sys','2010-11-09 22:52:55','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('39','sys','2010-11-09 22:56:39','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('40','sys','2010-11-09 23:11:22','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('41','sys','2010-11-10 00:12:13','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('42','sys','2010-11-10 00:15:58','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('43','sys','2010-11-10 00:17:49','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('44','sys','2010-11-13 21:36:19','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('45','sys','2010-11-13 21:39:09','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('46','sys','2010-11-13 21:44:25','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('47','sys','2010-11-13 21:47:44','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('48','sys','2010-11-13 21:51:27','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('49','sys','2010-11-14 09:50:03','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('50','sys','2010-11-14 09:56:56','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('51','sys','2010-11-14 10:02:37','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('52','sys','2010-11-14 10:14:17','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('53','sys','2010-11-14 10:17:32','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('54','sys','2010-11-14 10:20:00','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('55','sys','2010-11-14 10:21:56','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('56','sys','2010-11-16 21:10:09','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('57','sys','2010-11-16 21:41:10','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('58','sys','2010-11-16 22:51:47','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('59','sys','2010-11-16 23:07:14','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('60','sys','2010-11-21 14:22:15','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('61','sys','2010-11-21 14:33:42','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('62','sys','2010-11-21 14:53:45','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('63','sys','2010-11-21 15:02:47','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('64','sys','2010-11-21 15:06:48','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('65','sys','2010-11-21 15:26:16','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('66','sys','2010-11-21 15:36:55','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('67','sys','2010-11-21 15:39:13','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('68','sys','2010-11-21 15:40:25','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('69','sys','2010-11-21 15:48:27','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('70','sys','2010-11-21 15:49:19','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('71','sys','2010-11-21 15:49:54','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('72','sys','2010-11-21 15:51:26','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('73','sys','2010-11-21 16:02:10','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('74','sys','2010-11-21 17:09:02','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('75','sys','2010-11-21 17:28:29','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('76','sys','2010-11-21 17:30:35','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('77','sys','2010-11-21 17:31:12','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('78','sys','2010-11-21 17:31:39','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('79','sys','2010-11-21 17:31:53','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('80','sys','2010-11-21 17:42:02','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('81','sys','2010-11-21 17:58:49','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('82','sys','2010-11-21 18:00:48','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('83','sys','2010-11-21 18:08:41','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('84','sys','2010-11-21 18:20:25','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('85','sys','2010-11-21 18:32:27','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('86','sys','2010-11-21 19:10:29','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('87','sys','2010-11-21 19:18:31','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('88','sys','2010-11-21 19:48:39','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('89','sys','2010-11-21 20:17:51','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('90','sys','2010-11-21 20:19:38','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('91','sys','2010-11-21 20:25:53','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('92','sys','2010-11-21 20:26:09','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('93','sys','2010-11-21 20:34:53','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('94','sys','2010-11-21 20:55:31','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('95','sys','2010-11-21 22:33:53','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('96','sys','2010-11-21 22:39:53','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('97','sys','2010-11-22 21:26:17','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('98','sys','2010-11-22 21:49:02','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('99','sys','2010-11-22 22:16:02','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('100','sys','2010-11-22 22:29:46','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('101','sys','2010-11-22 22:32:06','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('102','sys','2010-11-22 22:33:26','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('103','sys','2010-11-23 21:12:29','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('104','sys','2010-11-23 21:31:03','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('105','sys','2010-11-23 23:22:52','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('106','sys','2010-11-24 11:03:39','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('107','user','2010-11-24 11:14:38','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('108','sys','2010-11-24 11:15:04','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('109','user','2010-11-24 11:15:36','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('110','sys','2010-11-24 11:16:24','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('111','user','2010-11-24 11:20:28','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('112','user','2010-11-24 11:40:08','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('113','sys','2010-11-24 11:42:39','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('114','user','2010-11-24 11:43:33','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('115','sys','2010-11-24 11:44:04','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('116','sys','2010-11-24 12:34:37','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('117','sys','2010-11-24 12:34:52','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('118','sys','2010-11-24 23:20:19','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('119','sys','2010-11-24 23:26:07','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('120','sys','2010-11-25 00:37:06','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('121','user','2010-11-25 00:42:34','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('122','sys','2010-11-25 22:32:32','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('123','sys','2010-11-25 22:50:37','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('124','sys','2010-11-25 23:01:29','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('125','sys','2010-11-26 09:59:07','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('126','sys','2010-11-26 10:47:50','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('127','sys','2010-11-26 10:53:25','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('128','sys','2010-11-26 10:56:44','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('129','sys','2010-11-26 10:59:04','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('130','sys','2010-11-26 11:04:20','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('131','sys','2010-11-26 11:36:23','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('132','sys','2010-11-26 11:40:55','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('133','sys','2010-11-26 11:50:52','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('134','sys','2010-11-26 11:56:16','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('135','sys','2010-11-26 12:02:19','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('136','sys','2010-11-26 12:07:07','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('137','sys','2010-11-26 14:20:43','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('138','sys','2010-11-26 14:30:46','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('139','sys','2010-11-26 14:36:30','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('140','sys','2010-11-26 15:06:00','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('141','sys','2010-11-26 15:24:56','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('142','sys','2010-11-26 16:39:52','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('143','sys','2010-11-26 16:39:54','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('144','sys','2010-11-26 17:15:14','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('145','sys','2010-11-26 19:38:10','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('146','sys','2010-11-26 19:45:24','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('147','sys','2010-11-26 19:51:57','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('148','sys','2010-11-26 19:56:15','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('149','sys','2010-11-26 20:03:02','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('150','sys','2010-11-26 20:04:40','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('151','sys','2010-11-26 20:07:40','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('152','sys','2010-11-26 20:12:57','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('153','sys','2010-11-26 20:21:59','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('154','sys','2010-11-26 20:22:31','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('155','sys','2010-11-26 21:10:15','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('156','sys','2010-11-26 21:18:23','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('157','sys','2010-11-26 21:21:04','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('158','sys','2010-11-26 21:28:14','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('159','sys','2010-11-26 21:43:50','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('160','user','2010-11-26 21:46:09','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('161','sys','2010-11-26 21:46:41','127.0.0.1','1','','0');");
E_D("insert into `trans_m_log` values('162','sys','2010-11-28 15:30:25','127.0.0.1','1','','0');");

@include("../../inc/footer.php");
?>